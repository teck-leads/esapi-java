
// You'll need the below URLs while following along with the lecture for practice.
     var root = "https://jsonplaceholder.typicode.com/posts/1";
    // var root = "https://jsonplaceholder.typicode.com/comments";
     var url = "https://raw.githubusercontent.com/imtiazahmad007/resources/master/some_random_text.txt";
    // 
    var url = "https://raw.githubusercontent.com/imtiazahmad007/resources/master/sample_table.html table fieldset:first";
    var url = "https://raw.githubusercontent.com/imtiazahmad007/resources/master/sample_table.html test";

$(function(){

    //first par start
    // $("button#btn_1").on("click", function(){

    //     // $("div.main").load(url);

    //     $.ajax(url,{
    //         dataType: 'html',
    //         method: 'GET',
    //         success: function(response){
    //             $("div.main").html(response);
    //         },
    //         error: function(request, errorType, msg){
    //             alert("some issue in calling");

    //         }
    //     });

    // });
    //first part ends


    $("button#btn_1").on("click", function(){

        // $("div.main").load(url);

        $.ajax(root,{
            dataType: 'json',
            method: 'GET',
            success: function(response){
               // $("div.main").html(response);
               console.log(response);
               var userId=response.userId;
               var title=response.title;
               alert(userId+" "+title);
               var $info =$("<p></p>");
              $info.text("userId is "+userId+" title is "+title);
              $("div.main").append($info);
               
            },
            error: function(request, errorType, msg){
                alert("some issue in calling");

            }
        });

    });

});
